package coe528.project;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Piratheipan_J
 */
public class FlightTest {
    
    public FlightTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
    
    /**
     * Test of getPrice method, of class Flight.
     */
    @org.junit.Test
    public void testGetPrice() {
        System.out.println("getPrice");
        Flight instance =new Flight(1222.99, 4.0, 4.5, "AirCamada");
        double expResult = 1222.99;
        double result = instance.getPrice();
        assertEquals(expResult, result,0.0);
    }

    /**
     * Test of setPrice method, of class Flight.
     */
    @org.junit.Test
    public void testSetPrice() {
        System.out.println("setPrice");
        double price = 1222.99;
        Flight instance = new Flight(1222.99, 4.0, 4.5, "AirCamada");
        instance.setPrice(price);
        assertEquals(price, instance.getPrice(),0.0);
    }

    /**
     * Test of getDuration method, of class Flight.
     */
    @org.junit.Test
    public void testGetDuration() {
        System.out.println("getDuration");
        Flight instance = new Flight(1222.99, 4.0, 4.5, "AirCamada");
        double expResult = 4.0;
        double result = instance.getDuration();
        assertEquals(expResult, result,0.0);
    }

    /**
     * Test of setDuration method, of class Flight.
     */
    @org.junit.Test
    public void testSetDuration() {
        System.out.println("setDuration");
        double duration = 4.0;
        Flight instance = new Flight(1222.99, 4.0, 4.5, "AirCamada");
        instance.setDuration(duration);
        assertEquals(duration, instance.getDuration(),0.0);

    }

    /**
     * Test of getRating method, of class Flight.
     */
    @org.junit.Test
    public void testGetRating() {
        System.out.println("getRating");
        Flight instance = new Flight(1222.99, 4.0, 4.5, "AirCanada");
        double expResult = 4.5;
        double result = instance.getRating();
        assertEquals(expResult, result, 0.0);
    }

    /**
     * Test of setRating method, of class Flight.
     */
    @org.junit.Test
    public void testSetRating() {
        System.out.println("setRating");
        double rating = 4.5;
        Flight instance = new Flight(1222.99, 4.0, 4.5, "AirCanada");
        instance.setRating(rating);
        assertEquals(rating, instance.getRating(), 0.0);
    }

    /**
     * Test of getAirLine method, of class Flight.
     */
    @org.junit.Test
    public void testGetAirLine() {
        System.out.println("getAirLine");
        Flight instance = new Flight(1222.99, 4.0, 4.5, "AirCanada");
        String expResult = "AirCanada";
        String result = instance.getAirLine();
        assertEquals(expResult, result);
    }

    /**
     * Test of setAirLine method, of class Flight.
     */
    @org.junit.Test
    public void testSetAirLine() {
        System.out.println("setAirLine");
        String AirLine = "AirCanada";
        Flight instance = new Flight(1222.99, 4.0, 4.5, "AirCanada");
        instance.setAirLine(AirLine);
        assertEquals(AirLine, instance.getAirLine());
    }

    /**
     * Test of repOK method, of class Flight.
     */
    @org.junit.Test
    public void testRepOK() {
        System.out.println("repOK");
        Flight instance = new Flight(1222.99, 4.0, 4.5, "AirCanada");
        boolean expResult = false;
        boolean result = instance.repOK();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class Flight.
     */
    @org.junit.Test
    public void testToString() {
        System.out.println("toString");
        Flight instance = new Flight(1222.99, 4.0, 4.5, "AirCanada");
        String expResult =("Airline: "+"AirCanada" +":" + " Rating: " + 4.5 + ", Duration of your stay: " + 4.0 + " days" + ", Price: $" + 1222.99);

        String result = instance.toString();
        assertEquals(expResult, result);
    }    
}