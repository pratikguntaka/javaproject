/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coe528.project;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Piratheipan_J
 */
public class sortHighToLowTest {
    
    public sortHighToLowTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of sort method, of class sortHighToLow.
     */
    @Test
    public void testSort() {
        System.out.println("sort");
        String[] s = {"AirCanada", "RedRocket","JetLines","AirWays"};
        sortHighToLow instance = new sortHighToLow();
        instance.sort(s);
        assertEquals(" RedRocket JetLines AirWays AirCanada", instance.toString());
    }
    
}
