package coe528.project;

public class sortRating extends sortList{
    /**OVERVIEW: sortRating is mutable, and unbounded, used
       to sort a set of rating for flights in either high to low,
       or low to high, as specified by user input. */
    
    /** The abstraction function is:
       for(int m = 0; m < rate.length; m++){ 
       rating[m] = rate[m]; }
       sorting.sort(rating);
       * 
    The rep invariant is: rating[] cannot be null.  */
    private String []rating = new String[4];
      
    public sortRating(double [] rate,sorter sorting){
         /** EFFECTS: Adds ratings to rating[] depending on high to low
            or low to high selection. */
        super(sorting);
        for (int i=0; i<rate.length;i++){
            rating[i]=(""+rate[i]);
        }
        System.out.print("Rating ");
    }
    
    @Override
    public void sort(){
        /** MODIFIES: rating[]. */
        /** EFFECTS: Sorts the array of ratings. */
        sorting.sort(rating);
    }
    
    @Override
    public String toString() {
        /** EFFECTS: Returns a string that contains the sorted list of ratings. */
        String output = new String();
        sorting.sort(rating);
        
        for (int h=0; h < rating.length; h++) {
            output = " " + rating[h];
        }
        return output;
    }
    public boolean repOK() {
        /** EFFECTS: Returns true if the rep invariant holds for this
                    objects; otherwise returns false. */
        for (int j=0; j<rating.length; j++){
            if (rating[j] == null) { return false; };
        }
        return true;
    }
}

