package coe528.project;
/** The abstraction function is: 
for(int m=0; m < air.length; m++) { airlines[m] = air[m];} 
sorting.sort(airlines);

The rep invariant is: airlines[] cannot be null 
*/

public class sortActivity extends sortList {
    /**OVERVIEW: sortActivity is mutable, and unbounded, used
       to sort a set of AirLine flights in either high to low,
       or low to high, as specified by user input. */
    
    /** The abstraction function is:
       for(int m = 0; m < air.length; m++){
       airlines[m] = air[m]; }
       sorting.sort(airlines);
    The rep invariant is: airlines[] cannot be null.  */
    private String []airlines = new String[4];
      
    public sortActivity(String [] air,sorter sorting){
        /** Requires: air cannot be null. */
        /** EFFECTS: Adds AirLine names to airline[] depending on high to low
            or low to high selection. */
        super(sorting);
        for (int i=0; i<air.length;i++){
            airlines[i]=air[i];
        }
        System.out.print("Airlines ");
    }
    
    public void sort(){
        /** MODIFIES: airlines[]. */
        /** EFFECTS: Sorts the array of AirLine names. */
        sorting.sort(airlines);
    }
    
    public String toString() {
        /** Effects: Returns a string that contains the sorted list of airline names. */
        String output = new String();
        sorting.sort(airlines);
        
        for (int h=0; h < airlines.length; h++) {
            output = " " + airlines[h];
        }
        return output;
    }
    public boolean repOK() {
        /** EFFECTS: Returns true if the rep invariant holds for this objects; otherwise returns false. */
        for (int j=0; j<airlines.length; j++){
            if (airlines[j] == null) { return false; };
        }
        return true;
    }
}