package coe528.project;

import java.util.ArrayList;
import java.util.Scanner;

public class mainClass {
    /**OVERVIEW: mainClass is immutable, unbounded, main interface 
       to start the program/allows access to ABC Travels. */
    
    /**The Abstract function is: 
     do{
        UserInterface person = new UserInterface();
        person.customer();
        
        person.chooseCateg();
            user = input.nextLine();
            if (user.equals("yes")) {
                ready = true;
            } else if (user.equals("no")) {
                ready = false;
            }
        } while (ready == false);
     
     The rep invariant is: 
     user must input only 'yes' or 'no' */
    
    public static void main(String[] args) {
        /** Effects: customer chooses to view details of another country or exit. */
        Scanner input=new Scanner(System.in);
        String user="";
        boolean ready=true;
        do{
        UserInterface person=new UserInterface();
        person.customer();
        
        ArrayList<Country> country = new ArrayList<>();
        person.chooseCateg();
            System.out.println("Do you want to exit, Enter yes or enter no to choose another country!");
            user = input.nextLine();
            if (user.equals("yes")) {
                ready = true;
            } else if (user.equals("no")) {
                ready = false;
            }
        } while (ready == false); 
    }
}

