package coe528.project;
import java.util.ArrayList;
// The Abstract function is: 
// 
public class Country{
    /**OVERVIEW; Country is a mutable, unbounded country, 
      each with a list of flights that can be added or shown. */
    
    /** The abstraction function is:     
   for (int k=0; k< flight.size(); k++){
            String p = p + "" + flight.get(k);
        }
   
   

   The rep invariant: 
        The Flight objects to be added cannot be null. */
    ArrayList<Flight> flight = new ArrayList<>();
    public static String []message=new String[4];
    int counter=0;
    public Country(){
        
    }
    public Country(double price, double duration, double rating, String AirLine){
        /** EFFECTS: Creates new Country object. */
        flight.add(new Flight(price,duration,rating,AirLine));
    }
    
    public void addFlight(double price, double duration, double rating, String AirLine){
        /** MODIFIES: this. */
        /** EFFECTS: adds a new flight object to this. */
        flight.add(new Flight(price,duration,rating,AirLine));
    }
    public String getFllight(){
        /** EFFECTS: Returns a list of flights for the country. */
        String p="";
        for (int i=0; i<flight.size(); i++){
            p=p+" "+flight.get(i);
        }
        return p;
    }

    public boolean repOK() {
        /** EFFECTS: Returns true if the rep invariant holds for this objects; otherwise returns false. */
        for (int j=0; j < flight.size(); j++) {
            if (flight.get(j) == null) { return false;};
        }
        return true;
    }
    public String toString() {
        /** EFFECTS: Returns a list of flights for the country. */
        String p = "";
        for (int i=0; i<flight.size(); i++){
            p=p+" "+flight.get(i);
        }
        return p;
    }
    public void Details(){
        /** EFFECTS: Displays the details of country object. */
        counter=0;
        for(Flight f: flight){
        message[counter]=f.toString();
        counter++;
        
        }
    }
}