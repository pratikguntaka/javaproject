package coe528.project;

public class sortDuration extends sortList{
    /**OVERVIEW: sortDuration is mutable, and unbounded, used
       to sort a set of duration times for flights in either high to low,
       or low to high, as specified by user input. */
    
    /** The abstraction function is:
       for(int m = 0; m < dur.length; m++){
       duration[m] = dur[m]; }
       sorting.sort(duration);
    The rep invariant is: duration[] cannot be null.  */
    private String []duration = new String[4];
      
    public sortDuration(double [] dur,sorter sorting){
        /** REQUIRES: dur cannot be null. */
        /** EFFECTS: Adds duration times to duration[] depending on high to low
            or low to high selection. */
        super(sorting);
        for (int i=0; i<dur.length;i++){
            duration[i]=(""+dur[i]);
        }
        System.out.print("Duration ");
    }
    
    public void sort(){
         /** MODIFIES: duration[]. */
        /** EFFECTS: Sorts the array of duration times. */
        sorting.sort(duration);
    }
    
    @Override
    public String toString() {
           /** EFFECTS: Returns a string that contains the sorted list of duration time. */
        String output = new String();
        sorting.sort(duration);
        
        for (int h=0; h < duration.length; h++) {
            output = " " + duration[h];
        }
        return output;
    }
    public boolean repOK() {
        /** EFFECTS: Returns true if the rep invariant holds for this
                    objects; otherwise returns false. */
        for (int j=0; j<duration.length; j++){
            if (duration[j] == null) { return false; };
        }
        return true;
 }
}


