package coe528.project;

import java.util.Scanner;
import java.io.*;
import java.util.ArrayList;

public class UserInterface {
    /**OVERVIEW: UserInterface is a immutable, unbounded, interface
       used for the user to interact with the program
       ABC Travels. */
    
    /** The abstraction function is: 
     * Scanner input = new Scanner(System.in);
        boolean ready = true;
        do {
            destination = input.nextLine();} 
            * while (ready == false);
            numPassengers = input.nextInt();
            Country (destination.equalsIgnoreCase("destination")) = new Country();
            addcountry(destination.equalsIgnoreCase("destination"));
            * 
        open = new Scanner(new File(file));
            * 
            * country = new ArrayList<>();
              country.add(place);
        * 
            * while (open.hasNext()) {
            cost = Double.parseDouble(open.next());
            duration = Double.parseDouble(open.next());
            rating = Double.parseDouble(open.next());
            airlines = open.next();
            place.addFlight(cost * numPassengers, duration, rating, airlines);
            sortAir[counter]=airlines;
            sortPrix[counter]=cost*numPassengers;
            sortRate[counter]=rating;
            sortdur[counter]=duration;
            counter++;
            * 
            *Scanner input = new Scanner(System.in);
            *choice = input.nextInt();
             
        }
        * 
    The rep invariant is: 
    * 
    * The destination input must equal the names of the countries provided, 
    * disregarding if the input is uppercase or lowercase. 
    * The number of passengers must be greater than 0 but less than 10.
    * The choice of the category must be selected using the integers according to the numbered list of categories displayed. 
    * if !(destination.equalsIgnoreCase("barbados") || destination.equalsIgnoreCase("italy") || destination.equalsIgnoreCase("japan")
                    || destination.equalsIgnoreCase("india") || destination.equalsIgnoreCase("chile")) { return false;}
      if (numPassengers <= 0) {
                return false;
            } else if (numPassengers > 10) {
                reutrn false;}
    * 
    * 
     */
    private String destination, file, airlines;
    private int numPassengers, choice, counter=0, selection;
    private double rating, cost, duration;
    boolean quit = false;
    Scanner open;
    ArrayList<Country> country;
    String []sortAir=new String[4];
    double []sortPrix=new double[4];
    double []sortRate=new double[4];
    double []sortdur=new double[4];
    boolean exitloop=false;
    String line;

    public UserInterface() {
    }

    public void fileopen(String file) {
        /**  Requires: the file must exist. */
        /** Effects: opens the file. */
        
        try {
            open = new Scanner(new File(file));
        } catch (Exception ex) {
            System.out.println("File not found");
        }
    }

    public void fileclose() {
        /** Effects: closes the file that is opened. */
        open.close();
    }

    public void filereader(Country place) {
        /** Requires: the country must not be null */
        /** Effects: the file is read and cost, duration, rating and airlines are declared.  */
        /** Modifies: it add the flight details to the country (place) */
        counter=0;
        while (open.hasNext()) {
            cost = Double.parseDouble(open.next());
            duration = Double.parseDouble(open.next());
            rating = Double.parseDouble(open.next());
            airlines = open.next();
            place.addFlight(cost * numPassengers, duration, rating, airlines);
            sortAir[counter]=airlines;
            sortPrix[counter]=cost*numPassengers;
            sortRate[counter]=rating;
            sortdur[counter]=duration;
            counter++;
        }
        for (Country c : country) {
            if (c.equals(place)) {
                c.Details();
            }
        }
    }
   

    public void addcountry(Country place) {
        /** Requires: place has to be of type Country */ 
        /** Effects: adds the place to the arraylist Country */
        country = new ArrayList<>();
        country.add(place);
        filereader(place);
    }

    public void chooseCateg() {
        /** Effects: customer chooses the category to sort by. */
        Scanner input = new Scanner(System.in);
        do {
            System.out.println("Choose what category you want to sort, Enter a number!");
            System.out.println("0. Exit");
            System.out.println("1. Airlines");
            System.out.println("2. Cost");
            System.out.println("3. Rating");
            System.out.println("4. Duration");
            System.out.print("Your choice: ");
            choice = input.nextInt();
            Country c=new Country();
            switch (choice) {
                case 1:
                    sortingTeachnique();
                    if (selection==1){
                        sortList air=new sortActivity(sortAir, new sortLowToHigh());
                        air.sort();
                    } else if (selection==2){
                        sortList air=new sortActivity(sortAir, new sortHighToLow());
                        air.sort();
                    }
                    exitloop=true;                   
                    break;
                case 2:
                    sortingTeachnique();
                    if (selection==1){
                        sortList cos=new sortPrice(sortPrix, new sortLowToHigh());
                        cos.sort();
                    } else if (selection==2){
                        sortList cos=new sortPrice(sortPrix, new sortHighToLow());
                        cos.sort();
                    }
                    exitloop=true;
                    break;
                case 3:
                    sortingTeachnique();
                    if (selection==1){
                        sortList rat=new sortRating(sortRate, new sortLowToHigh());
                        rat.sort();
                    } else if (selection==2){
                        sortList rat=new sortRating(sortRate, new sortHighToLow());
                        rat.sort();
                    }
                    exitloop=true;
                    break;
                case 4:
                    sortingTeachnique();
                    if (selection==1){
                        sortList dur=new sortDuration(sortdur, new sortLowToHigh());
                        dur.sort();
                    } else if (selection==2){
                        sortList dur=new sortDuration(sortdur, new sortHighToLow());
                        dur.sort();
                    }
                    exitloop=true;
                    break;
                default:
                    //System.out.println("Wrong choice.");
                    exitloop=false;
                    break;
            }
        } while (choice!=0);
        System.out.println();
    }
    
    public void sortingTeachnique(){
        /** Effects: Customer chooses the sorting method.  */
        Scanner input = new Scanner(System.in);
        do {
            System.out.println("Choose how you want to view the results, Enter a number!");
            System.out.println("1. Low to High");
            System.out.println("2. High to Low");
            System.out.print("Your choice : ");
            choice = input.nextInt();
            switch (choice) {
                case 1:
                    selection=1;
                    exitloop=true;
                    break;
                case 2:
                    selection=2;
                    exitloop=true;
                    break;
                default:
                    System.out.println("Wrong choice.");
                    exitloop=false;
                    break;
            }
        } while (exitloop==false);
        System.out.println();
    }
    
    public void customer() {
        /** Effects: customer selects the country and number of passengers */
        Scanner input = new Scanner(System.in);
        System.out.println("Welcome to ABC Travels!!!");
        boolean ready = true;
        System.out.println("Current vaction spots are:\n-Barbados\n-Japan\n-Italy\n-Chile\n-India\n");
        System.out.println("Enter Country: ");
        do {
            destination = input.nextLine();
            if (destination.equalsIgnoreCase("barbados") || destination.equalsIgnoreCase("italy") || destination.equalsIgnoreCase("japan")
                    || destination.equalsIgnoreCase("india") || destination.equalsIgnoreCase("chile")) {
                ready = true;
            } else {
                System.out.println("Please enter a valid country: ");
                ready = false;
            }
        } while (ready == false);

        System.out.println("Enter # of passengers: ");
        do {
            numPassengers = input.nextInt();
            if (numPassengers <= 0) {
                System.out.println("Enter a valid number! ");
                System.out.println("Enter # of passengers: ");
                ready = false;
            } else if (numPassengers > 10) {
                System.out.println("Maximum # of passengers is 10!");
                System.out.println("Enter # of passengers less than 10: ");
                ready = false;
            } else {
                ready = true;
            }
        } while (ready == false);
        if (destination.equalsIgnoreCase("barbados")) {
            file = "barbados.txt";
            fileopen(file);
            Country barbados = new Country();
            addcountry(barbados);
        } else if (destination.equalsIgnoreCase("italy")) {
            file = "italy.txt";
            fileopen(file);
            Country italy = new Country();
            addcountry(italy);
        } else if (destination.equalsIgnoreCase("india")) {
            file = "india.txt";
            fileopen(file);
            Country india = new Country();
            addcountry(india);
        } else if (destination.equalsIgnoreCase("japan")) {
            file = "japan.txt";
            fileopen(file);
            Country japan = new Country();
            addcountry(japan);
        } else if (destination.equalsIgnoreCase("chile")) {
            file = "chile.txt";
            fileopen(file);
            Country chile = new Country();
            addcountry(chile);
        } else {
        }
    }
    
    public boolean repOK() {
        /** EFFECTS: Returns true if the rep invariant holds for this objects; otherwise returns false. */
        if (!(destination.equalsIgnoreCase("barbados")))  {return false;}
        if (!(destination.equalsIgnoreCase("italy"))) {return false;}
        if (!(destination.equalsIgnoreCase("japan"))) {return false;}
        if (!(destination.equalsIgnoreCase("india"))) {return false;}
        if (!(destination.equalsIgnoreCase("chile"))) {return false;}
        
      if (numPassengers <= 0) {
                return false;
            } else if (numPassengers > 10) {
                return false;}
      return true;
    }
}