package coe528.project;

public interface sorter {
    /**OVERVIEW: sorter is immutable, unbounded, interface used
       to sort various lists from high to low, or low to high. */
    public abstract void sort(String []s);
    /** Requires: String[] s must not be null or empty.  */
    /** Effects: sorts the String[] s.  */
    /** Modifies: changes the arrangement of the objects in the list.  */
}
