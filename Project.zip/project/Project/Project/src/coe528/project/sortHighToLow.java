package coe528.project;

import java.util.Arrays;

public class sortHighToLow implements sorter {
/**OVERVIEW: sortHighToLow is immutable, and unbounded, used
       to sort a flight details as high to low,
       as specified by user input. */
    
    /** The abstraction function is:     
   for (int k=0; k < line.length; k++){
            String p = p + "" + line.[k];
        }
  
   The rep invariant: 
        line[] cannot be null. */
    String[] line = new String[4];

    @Override
    public void sort(String[] s) {
        /** REQUIRES: s[] not be null . */
        /** MODIFIES: s[] . */
        /** EFFECTS: sorts s[] from high to low,
            and prints the sorted list in that order. */
        int n = s.length;
        System.out.println("from High to Low: ");
        Arrays.sort(s);

        for (int i = n-1; i >=0; i--) {
            for (int j = 0; j < line.length; j++) {
                line[j] = Country.message[j];
                if (line[j].contains(s[i])) {
                    System.out.println(line[j]);
                }
            }
        }
        System.out.println("");
    }
    public String toString(){
        /** EFFECTS: Returns a string that contains lines of sorted flights
        from high to low. */
        String p="";
        for (int i=0; i<line.length; i++){
            p=p+" "+line[i];
        }
        return p;
    }
    
   
    public boolean repOK() {
    /** EFFECTS: Returns true if the rep invariant holds for this
                    objects; otherwise returns false. */
        for (int j=0; j < line.length; j++) {
            if (line[j] == null) { return false;};
        }
        return true;
    }
}
