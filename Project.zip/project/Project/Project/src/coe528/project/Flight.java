package coe528.project;
 
public class Flight {
    /**OVERVIEW: Flight is a mutable, unbounded flight for a country;
        each flight has its own characteristics in terms of price, duration,
        rating, and AirLine name. */
    
    /** The abstraction function is:     
 String p=("Airline: "+getAirLine() +":" + " Rating: " + getRating() + ", Duration of your stay: " + getDuration() + " days" + ", Price: $" + getPrice());


The rep invariant: 
price is a double, and not null.
duration is double, and not null.
rating is double, and not null.
airline is string which cannot be null or empty. */
    private double price; //Price of ticket for each passenger
    private double duration; //Number of days of vacation
    private double rating; //Rating out of 5.0
    private String AirLine; //What type of ticket passenger 
    
    public Flight(double price, double duration, double rating, String AirLine){
        /** EFFECTS: Creates new Flight object. */
        this.price = price;
        this.duration = duration;
        this.rating = rating;
        this.AirLine = AirLine;
    }
    
    public double getPrice(){
        /** EFFECTS: Returns price of flight. */
        return this.price;
    }
    
    public void setPrice(double price){
        /** MODIFIES: this. */
        /** EFFECTS: Sets the price of flight. */
        this.price = price;
    }
    
     public double getDuration(){
         /** EFFECTS: Returns the duration of vacation. */
        return this.duration;
    }
    
    public void setDuration(double duration){
        /** MODIFIES: this. */
        /** EFFECTS: Sets the duration for vacation. */
        this.duration = duration;
    }
     public double getRating(){
          /** EFFECTS: Returns the rating of vacation. */
        return this.rating;
    }
    
    public void setRating(double rating){
        /** MODIFIES: this. */
        /** EFFECTS: Sets the rating for vacation. */
        this.rating = rating;
    }
    
     public String getAirLine(){
          /** EFFECTS: Returns the AirLine name of flight. */
        return this.AirLine;
    }
    
    public void setAirLine(String AirLine){
        /** MODIFIES: this. */
        /** EFFECTS: Sets the AirLine name for flight. */
        this.AirLine = AirLine;
    }
    
     public boolean repOK() { 
       /** EFFECTS: Returns true if the rep invariant holds for this
                    objects; otherwise returns false. */
       if (getPrice() == 0) {
           return false; }
       if (getRating() == 0) { return false; }
       if (getDuration() == 0) { return false; }
       if (getAirLine() == null) { return false; }
       
       return true;
       }
     
    public String toString(){
        /** EFFECTS: Returns a string that contains details on the vacation
                     price, Airline name, duration, and rating. */
        String p=("Airline: "+getAirLine() +":" + " Rating: " + getRating() + ", Duration of your stay: " + getDuration() + " days" + ", Price: $" + getPrice());
        return p;
    }    
}
