package coe528.project;

import java.util.Arrays;

public class sortLowToHigh implements sorter {
/**OVERVIEW: sortLowtoHigh is immutable, and unbounded, used
       to sort a flight details as low to high,
       as specified by user input. */
    
    /** The abstraction function is:     
   for (int k=0; k < line.length; k++){
            String p = p + "" + line.[k];
        }
  
   The rep invariant: 
        line[] cannot be null. */
    String[] line = new String[4];

    @Override
    public void sort(String[] s) {
        /** REQUIRES: s[] not be null . */
        /** MODIFIES: s[] . */
        /** EFFECTS: sorts s[] from low to high,
            and prints the sorted list in that order. */
        System.out.println("from Low to High: ");
        Arrays.sort(s);
        for (int i = 0; i < s.length; i++) {
            for (int j = 0; j < line.length; j++) {
                line[j] = Country.message[j];
                if (line[j].contains(s[i])) {
                    System.out.println(line[j]);
                }
            }
        }
    }
    
    @Override
    public String toString(){
    /** EFFECTS: Returns a string that contains lines of sorted flights
        from Low to High. */
        String p="";
        for (int i=0; i<line.length; i++){
            p=p+" "+line[i];
        }
        return p;
    }
    public boolean repOK() {
    /** EFFECTS: Returns true if the rep invariant holds for this
                    objects; otherwise returns false. */
        for (int j=0; j < line.length; j++) {
            if (line[j] == null) { return false;};
        }
        return true;
    }
}
