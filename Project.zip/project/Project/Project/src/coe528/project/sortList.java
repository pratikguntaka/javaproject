package coe528.project;

public abstract class sortList {
     /**OVERVIEW: sortList is mutable, unbounded class used
       to be implemented to sort various lists of instances. */
    protected sorter sorting;
    
    protected sortList(sorter sorting){
        /** Effects: creates a new sorting object */
        /** Modifies: updates this (object) */
        this.sorting=sorting;
    }
    
    public abstract void sort();
    /** Effects: used to sort a list. */

}
